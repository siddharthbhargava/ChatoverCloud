ChatoverCloud
=============

Chat/support off the shelf app over cloud
